<?php $__env->startSection('title'); ?>
  Sign Up
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="modal modal-sheet position-static d-block bg-body-secondary p-4 py-md-5" tabindex="-1" role="dialog" id="modalSignin">
  <div class="modal-dialog" role="document">
	<div class="modal-content rounded-4 shadow">
	  <div class="modal-header p-5 pb-4 border-bottom-0">
		<h1 class="fw-bold mb-0 fs-2">Sign up for free</h1>
		<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	  </div>

	  <div class="modal-body p-5 pt-0">
			<form action="/signup" method="POST">
				<?php echo csrf_field(); ?>
				<div class="form-floating mb-3">
					<input type="input" class="form-control rounded-3" name="user_name" value="<?php echo e(old('user_name')); ?>" placeholder="name" required>
					<label for="floatingName">Your Name</label>
					<?php if(!empty($name_errors)): ?>
						<?php $__currentLoopData = $name_errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="alert alert-danger" role="alert">
								<?php echo e($error); ?>

							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>				
				</div>
				<div class="form-floating mb-3">
					<input type="email" class="form-control rounded-3" name="email" value="<?php echo e($email ?? old('email')); ?>" placeholder="name@example.com">
					<label for="floatingInput">Email address</label>
					<?php if(!empty($email_errors)): ?>
						<?php $__currentLoopData = $email_errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="alert alert-danger" role="alert">
								<?php echo e($error); ?>

							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
				<button class="w-100 mb-2 btn btn-lg rounded-3 btn-primary" type="submit">Sign up</button>
				<small class="text-body-secondary">By clicking Sign up, you agree to the terms of use.</small>
				<hr class="my-4">
			</form>
	  </div>
	</div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/swl/Documents/pp2/webDev/resources/views/signup.blade.php ENDPATH**/ ?>