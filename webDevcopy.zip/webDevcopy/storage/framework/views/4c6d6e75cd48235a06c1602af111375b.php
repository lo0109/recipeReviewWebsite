<?php $__env->startSection('title'); ?>
  Edit Comment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Comment</h1>
    
    <form action="/comment/update/<?php echo e($comment->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="comment" class="form-label">Comment</label>
            <input class="form-control" id="comment" name="comment" rows="4" placeholder="Pleaes enter at least 3 words." pattern="(\b[A-Za-z]+\b[\s]*){3,}" title="Please enter at least 3 words." required><?php echo e($comment->comment); ?></input>
        </div>
        
        <div class="mb-3">
            <label>Rating: </label>
            <?php for($i = 1; $i <= 5; $i++): ?>
                <input class="form-check-input" type="radio" name="rating" value="<?php echo e($i); ?>" 
                    <?php echo e($comment->rating == $i ? 'checked' : ''); ?> required>
                <label><?php echo e($i); ?></label>
            <?php endfor; ?>
        </div>
        
        <button type="submit" class="btn btn-primary">Update Comment</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/swl/Documents/pp2/webDev/resources/views/edit_comment.blade.php ENDPATH**/ ?>