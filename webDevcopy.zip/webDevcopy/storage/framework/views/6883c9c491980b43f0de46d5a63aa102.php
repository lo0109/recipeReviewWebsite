<?php $__env->startSection('title'); ?>
  Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="album py-5 bg-body-tertiary">
    <div class="container">
      <?php if(session('name_altered')): ?>
      <div class="alert alert-warning">
          <?php echo e(session('name_altered')); ?>

      </div>
      <?php endif; ?>
      <?php if(!empty($select_category)): ?>
        <div class="alert alert-primary" role="alert">
          Showing recipes for category: <?php echo e($select_category); ?>

        </div>
      <?php endif; ?>
      <?php if(empty($recipes)): ?>
        <div class="alert alert-danger" role="alert">
          No recipes found
        </div>
      <?php else: ?>
        <div class="col-sm-2 mb-3">
          <form method="GET" action="/">
            <select class="form-select" name="sort_by" onchange="this.form.submit()">
              <option selected>Default sorting</option>
              <option value="1" <?php echo e(request('sort_by') == '1' ? 'selected' : ''); ?>>Name(asc)</option>
              <option value="2"<?php echo e(request('sort_by') == '2' ? 'selected' : ''); ?>>Name(dsc)</option>
              <option value="3"<?php echo e(request('sort_by') == '3' ? 'selected' : ''); ?>>Rating(asc)</option>
              <option value="4"<?php echo e(request('sort_by') == '4' ? 'selected' : ''); ?>>Rating(dsc)</option>
              <option value="5" <?php echo e(request('sort_by') == '5' ? 'selected' : ''); ?>>Time(asc)</option>
              <option value="6"<?php echo e(request('sort_by') == '6' ? 'selected' : ''); ?>>Time(dsc)</option>
              <option value="7"<?php echo e(request('sort_by') == '7' ? 'selected' : ''); ?>>Calories(asc)</option>
              <option value="8"<?php echo e(request('sort_by') == '8' ? 'selected' : ''); ?>>Calories(dsc)</option>
              <option value="9"<?php echo e(request('sort_by') == '9' ? 'selected' : ''); ?>>No. of Reviews (asc)</option>
              <option value="10"<?php echo e(request('sort_by') == '10' ? 'selected' : ''); ?>>No. of Reviews (dsc)</option>

            </select>
          </form>
        </div>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
          <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
              <div class="card shadow-sm">
                <?php $rating = $recipe->rating; 
                $colour = $rating>=4 ? "text-bg-success" : ($rating>=3? "text-bg-warning" : "text-bg-secondary");
                ?>
                <span class="position-absolute top-10 start-10 badge rounded-pill <?php echo e($colour); ?>">
                  <?php echo e($rating ? "Avg rating: $rating" : 'no rating'); ?>

                </span>  
                <img src="<?php echo e(url("$recipe->img")); ?>" alt="<?php echo e($recipe->recipe); ?>" class="img-fluid">
                <div class="card-body">
                  <p class="card-text"><?php echo e($recipe->recipe); ?></p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                      <!-- View button - links to recipe/{id} page -->
                      <a href="/recipe/<?php echo e($recipe->id); ?>" class="btn btn-sm btn-outline-secondary">View</a>
                      <!-- Bookmark button with AJAX toggle -->
                      <a href="/category/<?php echo e($recipe->category_id); ?>" class="btn btn-sm btn-outline-secondary">
                        Category:<?php echo e($recipe->category); ?>

                      </a>      
                  
                    </div>
                    <div>
                    <small>No. of reviews: <?php echo e($recipe->review); ?> </small><br>
                      
                      <small><?php echo e($recipe->calories); ?> kcal</small><br>
                      <small class="text-body-secondary">Total time: <?php echo e($recipe->total_time); ?> mins</small>
                    </div>
                    </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<!-- <?php $__env->startSection('scripts'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Event listener for bookmark buttons
    document.querySelectorAll('.bookmark-btn').forEach(button => {
      button.addEventListener('click', function () {
        let recipeId = this.dataset.id;
        let button = this;

        fetch(`/bookmark/${recipeId}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
          }
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            // Update button label based on the new bookmark status
            button.textContent = data.bookmarked ? 'Bookmarked' : 'Bookmark';
          }
        });
      });
    });
  });
</script>
<?php $__env->stopSection(); ?> -->

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/swl/Documents/pp2/webDev/resources/views/home.blade.php ENDPATH**/ ?>