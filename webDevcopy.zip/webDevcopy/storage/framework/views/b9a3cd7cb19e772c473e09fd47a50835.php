<?php $__env->startSection('title'); ?>
  Recipe: <?php echo e($recipe->recipe); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
	
		<!-- Left Column: Ingredients -->
		<div class="col-md-3">
			<img src="<?php echo e(url("$recipe->img")); ?>" alt="<?php echo e($recipe->recipe); ?>" class="img-fluid">
			<h4>Ingredients</h4>
			<ul>
				<?php $__currentLoopData = explode(';', $recipe->ingredients); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($ingredient); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
			<p>Preparation Time: <?php echo e($recipe->preparation_time); ?> mins</p>
			<p>Cooking Time: <?php echo e($recipe->cook_time); ?> mins</p>
			<p>Calories: <?php echo e($recipe->calories); ?> kcal</p>
			<p>Category: <?php echo e($recipe->category); ?></p>

		</div>

		<!-- Middle Column: Instructions -->
		<div class="col-md-6">
			<div class="row">
				<div class="col-md-9">
					<h1><?php echo e($recipe->recipe); ?></h1>
				</div>
				<div class="col-md-3">
					<small>Updated by: <?php echo e($author_name ?? 'Admin'); ?></small><br>
					<small>On: <?php echo e($recipe->update_time ?? 'No update'); ?></small>
					<?php if(session()->has('user_name')): ?>
						<a class="btn btn-warning" href='/edit_item/<?php echo e($recipe->id); ?>'>Edit Recipe</a>
						<form action="/delete_item/<?php echo e($recipe->id); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this recipe?');">
							<?php echo csrf_field(); ?>
							<button type="submit" class="btn btn-danger">Delete Recipe</button>
						</form>
					<?php endif; ?>
				</div>
			</div>
			<h4>Instructions</h4>
			<?php $i = 0; ?>
			<?php $__currentLoopData = explode(';', $recipe->instructions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instruction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<p>Step <?php echo e($i+=1); ?></p>
			<p><?php echo e($instruction); ?></p>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

		<!-- Right Column: Comment Form -->
		
		<div class="col-md-3">
			<!-- Display login form if user is not logged in -->
			<?php if(!session()->has('user_name')): ?>
				<h5>Login/SignUp to leave a comment</h5>
				<form action="/login" method="POST">
					<?php echo csrf_field(); ?>
					<div class="mb-3">
						<input type="email" class="form-control" name="email" placeholder="Enter your email" required>
					</div>
					<button type="submit" class="btn btn-primary w-100">Login/SignUp</button>
				</form>
			<?php elseif($userHasCommented): ?>
				<h5>You have already left a comment.</h5>
			<?php else: ?>
				<form action="/comment/<?php echo e($recipe->id); ?>" method="POST">
				<?php echo csrf_field(); ?> <!-- This generates the CSRF token for security -->
				<input type="hidden" name="recipe_id" value="<?php echo e($recipe->id); ?>">
				<div class="mb-3">
					<h4>Leave a Comment</h4>
					<strong>Your Name: <?php echo e(session('user_name')); ?></strong>
				</div>
				<div class="mb-3">
					<label for="comment" class="form-label">Comment</label>
					<input class="form-control" id="comment" name="comment" rows="4" placeholder="Pleaes enter at least 3 words." pattern="(\b[A-Za-z]+\b[\s]*){3,}" title="Please enter at least 3 words." required></input>
				</div>
				<div class="mb-3">
					<label>Rating: </label>
					<?php for($i = 1; $i <= 5; $i++): ?>
						<input class="form-check-input" type="radio" name="rating" id="inlineRadio1" value="<?php echo e($i); ?>" required>
						<label><?php echo e($i); ?></label>
					<?php endfor; ?>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
				</form><br>
			<?php endif; ?>
			<div>
				<h4>Comments</h4>
				<div style="max-height: 300px; overflow-y: auto;">
					<!-- Display existing comments for this recipe -->
					<?php if(!empty($comments)): ?>
						<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="mb-3">
							<p>User: <?php echo e($comment->user_name); ?>	Rating: <?php echo e($comment->rating); ?></p>
							<p>Comment date:<?php echo e($comment-> c_date); ?></p>
							<p><?php echo e($comment->comment); ?></p>
							<?php if(session()->has('user_id') && session('user_id') == $comment->user_id): ?>
								<a class="btn btn-warning" href="/comment/edit/<?php echo e($comment->id); ?>">Edit</a>
								<form action="/comment/delete/<?php echo e($comment->id); ?>" method="POST" 
									onsubmit="return confirm('Are you sure you want to delete this comment?');">
									<?php echo csrf_field(); ?>
									<button type="submit" class="btn btn-danger">Delete</button>
								</form>
							<?php endif; ?>
							<hr>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<div class="mb-3">
						<strong>Be the first one to comment.</strong><br>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<!-- <?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const commentInput = document.getElementById('comment');
        commentInput.addEventListener('input', function () {
            const pattern = /(\b[A-Za-z]+\b[\s]*){3,}/;
            if (commentInput.validity.patternMismatch) {
                commentInput.setCustomValidity("Please enter at least 3 words in your comment.");
            } else {
                commentInput.setCustomValidity(''); // Reset the message
            }
        });
        

    });
</script>
<?php $__env->stopSection(); ?> -->
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/swl/Documents/pp2/webDev/resources/views/recipe.blade.php ENDPATH**/ ?>